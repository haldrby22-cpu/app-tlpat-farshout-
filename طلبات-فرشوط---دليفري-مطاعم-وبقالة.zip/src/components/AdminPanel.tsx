import React, { useState } from 'react';
import { Shop, MenuItem, CategoryType } from '../types';
import { Plus, Trash2, Store, Utensils, Coffee, ShieldCheck, Image, FileText, DollarSign, Clock, MapPin, Tag } from 'lucide-react';

interface AdminPanelProps {
  shops: Shop[];
  menuItems: MenuItem[];
  onAddShop: (shop: Shop) => void;
  onDeleteShop: (shopId: string) => void;
  onAddMenuItem: (item: MenuItem) => void;
  onDeleteMenuItem: (itemId: string) => void;
}

export default function AdminPanel({
  shops,
  menuItems,
  onAddShop,
  onDeleteShop,
  onAddMenuItem,
  onDeleteMenuItem,
}: AdminPanelProps) {
  // New Shop Form State
  const [shopName, setShopName] = useState('');
  const [shopCategory, setShopCategory] = useState<CategoryType>('restaurants');
  const [shopImage, setShopImage] = useState('');
  const [shopRating, setShopRating] = useState('4.5');
  const [shopDeliveryTime, setShopDeliveryTime] = useState('30');
  const [shopDeliveryFee, setShopDeliveryFee] = useState('10');
  const [shopMinOrder, setShopMinOrder] = useState('20');
  const [shopDistance, setShopDistance] = useState('1.5');
  const [shopTagsInput, setShopTagsInput] = useState('');

  // New MenuItem Form State
  const [selectedShopId, setSelectedShopId] = useState(shops[0]?.id || '');
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');
  const [itemPrice, setItemPrice] = useState('');
  const [itemImage, setItemImage] = useState('');
  const [itemRating, setItemRating] = useState('4.8');
  const [isPopular, setIsPopular] = useState(false);

  // Form validations
  const [shopError, setShopError] = useState('');
  const [itemError, setItemError] = useState('');
  const [shopSuccess, setShopSuccess] = useState('');
  const [itemSuccess, setItemSuccess] = useState('');

  const handleCreateShop = (e: React.FormEvent) => {
    e.preventDefault();
    setShopError('');
    setShopSuccess('');

    if (!shopName.trim()) {
      setShopError('الرجاء إدخال اسم المتجر');
      return;
    }

    // Default image if empty
    const imgUrl = shopImage.trim() || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=600&q=80';
    const tags = shopTagsInput
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    const newShop: Shop = {
      id: `shop-${Date.now()}`,
      name: shopName.trim(),
      category: shopCategory,
      image: imgUrl,
      rating: parseFloat(shopRating) || 4.5,
      reviewsCount: Math.floor(50 + Math.random() * 450),
      deliveryTime: parseInt(shopDeliveryTime) || 30,
      deliveryFee: parseInt(shopDeliveryFee) || 0,
      minOrder: parseInt(shopMinOrder) || 15,
      distance: parseFloat(shopDistance) || 1.2,
      tags: tags.length > 0 ? tags : ['جديد', 'موصى به'],
      featured: true,
    };

    onAddShop(newShop);
    setShopSuccess(`تمت إضافة المتجر "${newShop.name}" بنجاح!`);
    
    // Reset
    setShopName('');
    setShopImage('');
    setShopTagsInput('');
    if (!selectedShopId) {
      setSelectedShopId(newShop.id);
    }
  };

  const handleCreateMenuItem = (e: React.FormEvent) => {
    e.preventDefault();
    setItemError('');
    setItemSuccess('');

    const targetShopId = selectedShopId || (shops[0]?.id || '');

    if (!targetShopId) {
      setItemError('الرجاء اختيار متجر أولاً أو إضافة متجر جديد');
      return;
    }
    if (!itemName.trim()) {
      setItemError('الرجاء إدخال اسم الوجبة/المنتج');
      return;
    }
    if (!itemPrice.trim() || isNaN(parseFloat(itemPrice))) {
      setItemError('الرجاء إدخال سعر صحيح للمنتج');
      return;
    }

    const imgUrl = itemImage.trim() || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=400&q=80';

    const newItem: MenuItem = {
      id: `item-${Date.now()}`,
      shopId: targetShopId,
      name: itemName.trim(),
      description: itemDescription.trim() || 'مكونات طازجة ومحضرة بعناية فائقة عند الطلب.',
      price: parseFloat(itemPrice),
      image: imgUrl,
      rating: parseFloat(itemRating) || 4.8,
      popular: isPopular,
    };

    onAddMenuItem(newItem);
    setItemSuccess(`تمت إضافة المنتج "${newItem.name}" بنجاح!`);

    // Reset
    setItemName('');
    setItemDescription('');
    setItemPrice('');
    setItemImage('');
    setIsPopular(false);
  };

  return (
    <div className="space-y-8">
      {/* Title */}
      <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
        <div className="h-12 w-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-2xl">
          ⚙️
        </div>
        <div>
          <h2 className="text-xl font-extrabold text-slate-800">لوحة التحكم وإدارة التطبيق</h2>
          <p className="text-xs text-slate-400 mt-1">تعديل المتاجر، إضافة مطاعم، بقالات، كافيهات، أو منتجات جديدة فوراً</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Create New Shop Form */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm">
            <h3 className="font-extrabold text-base text-slate-800 mb-4 pb-2 border-b border-slate-50 flex items-center gap-2">
              <Plus className="h-5 w-5 text-red-500" />
              <span>إضافة متجر جديد (مطعم، بقالة، كافيه)</span>
            </h3>

            <form onSubmit={handleCreateShop} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">اسم المتجر *</label>
                <input
                  type="text"
                  required
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  placeholder="مثال: شاورما كرم الشام، سوبرماركت سعودي"
                  className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 placeholder-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">النوع / القسم *</label>
                  <select
                    value={shopCategory}
                    onChange={(e) => setShopCategory(e.target.value as CategoryType)}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 bg-white"
                  >
                    <option value="restaurants">🍔 مطعم</option>
                    <option value="grocery">🥦 بقالة وسوبرماركت</option>
                    <option value="cafes">☕ كافيه وحلويات</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">التقييم الافتراضي</label>
                  <input
                    type="number"
                    step="0.1"
                    min="1"
                    max="5"
                    value={shopRating}
                    onChange={(e) => setShopRating(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">رابط صورة المتجر (اختياري)</label>
                <input
                  type="url"
                  value={shopImage}
                  onChange={(e) => setShopImage(e.target.value)}
                  placeholder="رابط الصورة (إن وجد) أو سيتم اختيار صورة تلقائية"
                  className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 placeholder-slate-300 text-left"
                  style={{ direction: 'ltr' }}
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1.5">وقت التوصيل (دقيقة)</label>
                  <input
                    type="number"
                    value={shopDeliveryTime}
                    onChange={(e) => setShopDeliveryTime(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1.5">رسوم التوصيل (ج.م)</label>
                  <input
                    type="number"
                    value={shopDeliveryFee}
                    onChange={(e) => setShopDeliveryFee(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1.5">حد أدنى للطلب (ج.م)</label>
                  <input
                    type="number"
                    value={shopMinOrder}
                    onChange={(e) => setShopMinOrder(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">المسافة كم</label>
                  <input
                    type="number"
                    step="0.1"
                    value={shopDistance}
                    onChange={(e) => setShopDistance(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">الوسوم (مفصولة بفاصلة)</label>
                  <input
                    type="text"
                    value={shopTagsInput}
                    onChange={(e) => setShopTagsInput(e.target.value)}
                    placeholder="كشري, مصري, لذيذ"
                    className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 placeholder-slate-300"
                  />
                </div>
              </div>

              {shopError && <p className="text-xs text-red-500 font-semibold">{shopError}</p>}
              {shopSuccess && <p className="text-xs text-emerald-600 font-semibold">{shopSuccess}</p>}

              <button
                type="submit"
                className="w-full bg-red-500 text-white font-bold rounded-xl py-3 hover:bg-red-600 transition-colors cursor-pointer"
              >
                إضافة المتجر الآن
              </button>
            </form>
          </div>

          {/* Add Menu Item Form */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm">
            <h3 className="font-extrabold text-base text-slate-800 mb-4 pb-2 border-b border-slate-50 flex items-center gap-2">
              <Plus className="h-5 w-5 text-red-500" />
              <span>إضافة منتج أو وجبة لمتجر</span>
            </h3>

            <form onSubmit={handleCreateMenuItem} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">اختر المتجر التابع له المنتج *</label>
                <select
                  value={selectedShopId}
                  onChange={(e) => setSelectedShopId(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 bg-white"
                >
                  <option value="">-- اختر المتجر --</option>
                  {shops.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.category === 'restaurants' ? 'مطعم' : s.category === 'grocery' ? 'بقالة' : 'كافيه'})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">اسم الوجبة/المنتج *</label>
                  <input
                    type="text"
                    required
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    placeholder="مثال: دبل تشيز برجر بيف"
                    className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 placeholder-slate-300"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">السعر ج.م *</label>
                  <input
                    type="number"
                    required
                    value={itemPrice}
                    onChange={(e) => setItemPrice(e.target.value)}
                    placeholder="15"
                    className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 placeholder-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">وصف المكونات / المنتج</label>
                <textarea
                  value={itemDescription}
                  onChange={(e) => setItemDescription(e.target.value)}
                  placeholder="مكون من لحم بقري طازج، جبن شيدر، خس طازج وصوص خاص"
                  rows={2}
                  className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 placeholder-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">رابط الصورة (اختياري)</label>
                  <input
                    type="url"
                    value={itemImage}
                    onChange={(e) => setItemImage(e.target.value)}
                    placeholder="رابط صورة الوجبة"
                    className="w-full rounded-xl border border-slate-200 px-4 py-2 text-sm text-slate-800 focus:outline-none focus:border-red-400 placeholder-slate-300 text-left"
                    style={{ direction: 'ltr' }}
                  />
                </div>

                <div className="flex items-center gap-2 pt-6">
                  <input
                    type="checkbox"
                    id="isPopular"
                    checked={isPopular}
                    onChange={(e) => setIsPopular(e.target.checked)}
                    className="rounded text-red-500 focus:ring-red-400"
                  />
                  <label htmlFor="isPopular" className="text-xs font-bold text-slate-600 cursor-pointer">
                    تمييز كـ "شائع 🔥"
                  </label>
                </div>
              </div>

              {itemError && <p className="text-xs text-red-500 font-semibold">{itemError}</p>}
              {itemSuccess && <p className="text-xs text-emerald-600 font-semibold">{itemSuccess}</p>}

              <button
                type="submit"
                className="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl py-3 transition-colors cursor-pointer"
              >
                إضافة المنتج للقائمة
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Existing Shops List & Delete Actions */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm">
            <h3 className="font-extrabold text-base text-slate-800 mb-2 pb-2 border-b border-slate-50 flex items-center gap-2">
              <Store className="h-5 w-5 text-red-500" />
              <span>المتاجر النشطة حالياً ({shops.length})</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4 font-medium">يمكنك حذف أي متجر لإزالته تماماً من التطبيق فوراً.</p>

            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
              {shops.map((shop) => {
                const shopItemsCount = menuItems.filter((i) => i.shopId === shop.id).length;
                return (
                  <div
                    key={shop.id}
                    className="flex items-center justify-between p-3 rounded-2xl border border-slate-100 bg-slate-50/50 hover:border-red-100 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={shop.image}
                        alt={shop.name}
                        referrerPolicy="no-referrer"
                        className="h-10 w-10 object-cover rounded-xl bg-white border border-slate-100"
                      />
                      <div>
                        <h4 className="font-bold text-slate-800 text-sm">{shop.name}</h4>
                        <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-400 font-bold">
                          <span>
                            {shop.category === 'restaurants' ? '🍔 مطعم' : shop.category === 'grocery' ? '🥦 بقالة' : '☕ كافيه'}
                          </span>
                          <span>•</span>
                          <span>{shopItemsCount} منتج</span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`هل أنت متأكد من حذف المتجر "${shop.name}" وجميع وجباته بالكامل؟`)) {
                          onDeleteShop(shop.id);
                        }
                      }}
                      className="text-xs text-slate-400 hover:text-white hover:bg-red-500 p-2 rounded-xl transition-all cursor-pointer"
                      title="حذف المتجر"
                    >
                      <Trash2 className="h-4.5 w-4.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Current Products list to delete products */}
          <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm">
            <h3 className="font-extrabold text-base text-slate-800 mb-2 pb-2 border-b border-slate-50 flex items-center gap-2">
              <Utensils className="h-5 w-5 text-red-500" />
              <span>إدارة المنتجات النشطة ({menuItems.length})</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4 font-medium">قائمة بالمنتجات المتاحة حالياً عبر المتاجر.</p>

            <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
              {menuItems.map((item) => {
                const shopName = shops.find((s) => s.id === item.shopId)?.name || 'متجر غير معروف';
                return (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 rounded-2xl border border-slate-100 bg-slate-50/50 hover:border-red-100 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="h-10 w-10 object-cover rounded-xl bg-white border border-slate-100"
                      />
                      <div>
                        <h4 className="font-bold text-slate-800 text-sm">{item.name}</h4>
                        <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-400 font-bold">
                          <span className="text-red-500 font-extrabold">{item.price} ج.م</span>
                          <span>•</span>
                          <span>التابع لـ: {shopName}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`هل تريد حذف وجبة "${item.name}"؟`)) {
                          onDeleteMenuItem(item.id);
                        }
                      }}
                      className="text-xs text-slate-400 hover:text-white hover:bg-red-500 p-2 rounded-xl transition-all cursor-pointer"
                      title="حذف المنتج"
                    >
                      <Trash2 className="h-4.5 w-4.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
