import { useState, useEffect } from 'react';
import {
  Search,
  ShoppingBag,
  History,
  TrendingUp,
  MapPin,
  Compass,
  ArrowRight,
  Sparkles,
  Utensils,
  Coffee,
  Store,
  ChevronLeft,
  Check,
  Clock,
  Heart,
  X
} from 'lucide-react';

import { SHOPS, MENU_ITEMS } from './data';
import { Shop, MenuItem, CartItem, Order, CategoryType, OrderStatus, PromoCode } from './types';
import ShopCard from './components/ShopCard';
import ItemCard from './components/ItemCard';
import Cart from './components/Cart';
import OrderTracker from './components/OrderTracker';
import OrderHistory from './components/OrderHistory';
import AdminPanel from './components/AdminPanel';

export default function App() {
  // Navigation & Filtering
  const [activeTab, setActiveTab] = useState<'explore' | 'cart' | 'history' | 'tracking' | 'admin'>('explore');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('restaurants');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedShopId, setSelectedShopId] = useState<string | null>(null);

  // Shops and Menu Items
  const [shops, setShops] = useState<Shop[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);

  // Orders State
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrderId, setActiveOrderId] = useState<string | null>(null);

  // Toast notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Load from local storage on mount
  useEffect(() => {
    try {
      const savedShops = localStorage.getItem('talabat_shops');
      if (savedShops) {
        setShops(JSON.parse(savedShops));
      } else {
        setShops(SHOPS);
      }

      const savedMenuItems = localStorage.getItem('talabat_menu_items');
      if (savedMenuItems) {
        setMenuItems(JSON.parse(savedMenuItems));
      } else {
        setMenuItems(MENU_ITEMS);
      }

      const savedCart = localStorage.getItem('talabat_cart');
      if (savedCart) setCart(JSON.parse(savedCart));

      const savedOrders = localStorage.getItem('talabat_orders');
      if (savedOrders) setOrders(JSON.parse(savedOrders));

      const savedActiveOrderId = localStorage.getItem('talabat_active_order_id');
      if (savedActiveOrderId) setActiveOrderId(savedActiveOrderId);
    } catch (e) {
      console.error('Failed to load local storage state', e);
    }
  }, []);

  // Save state to local storage when changed
  useEffect(() => {
    if (shops.length > 0) {
      localStorage.setItem('talabat_shops', JSON.stringify(shops));
    }
  }, [shops]);

  useEffect(() => {
    if (menuItems.length > 0) {
      localStorage.setItem('talabat_menu_items', JSON.stringify(menuItems));
    }
  }, [menuItems]);

  useEffect(() => {
    localStorage.setItem('talabat_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('talabat_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    if (activeOrderId) {
      localStorage.setItem('talabat_active_order_id', activeOrderId);
    } else {
      localStorage.removeItem('talabat_active_order_id');
    }
  }, [activeOrderId]);

  // Admin Handlers
  const handleAddShop = (newShop: Shop) => {
    setShops([newShop, ...shops]);
    showToast(`تمت إضافة المتجر "${newShop.name}" بنجاح`, 'success');
  };

  const handleDeleteShop = (shopId: string) => {
    const deletedShop = shops.find((s) => s.id === shopId);
    setShops(shops.filter((s) => s.id !== shopId));
    // Also delete any menu items associated with this shop
    setMenuItems(menuItems.filter((m) => m.shopId !== shopId));
    if (deletedShop) {
      showToast(`تم حذف المتجر "${deletedShop.name}" وجميع منتجاته`, 'info');
    }
    if (selectedShopId === shopId) {
      setSelectedShopId(null);
    }
  };

  const handleAddMenuItem = (newItem: MenuItem) => {
    setMenuItems([newItem, ...menuItems]);
    showToast(`تمت إضافة المنتج "${newItem.name}" بنجاح`, 'success');
  };

  const handleDeleteMenuItem = (itemId: string) => {
    const deletedItem = menuItems.find((m) => m.id === itemId);
    setMenuItems(menuItems.filter((m) => m.id !== itemId));
    if (deletedItem) {
      showToast(`تم حذف المنتج "${deletedItem.name}"`, 'info');
    }
  };

  // Show dynamic toast
  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Helper: Get Active Order
  const activeOrder = orders.find((o) => o.id === activeOrderId);

  // Cart Handlers
  const handleAddToCart = (item: MenuItem) => {
    const existing = cart.find((i) => i.item.id === item.id);
    if (existing) {
      setCart(cart.map((i) => (i.item.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)));
    } else {
      setCart([...cart, { item, quantity: 1 }]);
    }
    showToast(`تمت إضافة "${item.name}" إلى السلة`);
  };

  const handleRemoveFromCart = (item: MenuItem) => {
    const existing = cart.find((i) => i.item.id === item.id);
    if (!existing) return;

    if (existing.quantity === 1) {
      setCart(cart.filter((i) => i.item.id !== item.id));
      showToast(`تمت إزالة "${item.name}" من السلة`, 'info');
    } else {
      setCart(cart.map((i) => (i.item.id === item.id ? { ...i, quantity: i.quantity - 1 } : i)));
    }
  };

  const handleUpdateCartQty = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      const itemToRemove = cart.find((i) => i.item.id === itemId);
      setCart(cart.filter((i) => i.item.id !== itemId));
      if (itemToRemove) {
        showToast(`تمت إزالة "${itemToRemove.item.name}" من السلة`, 'info');
      }
    } else {
      setCart(cart.map((i) => (i.item.id === itemId ? { ...i, quantity: newQty } : i)));
    }
  };

  const handleClearCart = () => {
    setCart([]);
    showToast('تم إفراغ السلة بالكامل', 'info');
  };

  // Checkout Handler
  const handleCheckout = (
    address: string,
    phone: string,
    paymentMethod: string,
    notes: string,
    appliedPromo?: PromoCode,
    discountAmount?: number
  ) => {
    // We assume all items in the cart are from the same shop for delivery logic simplicity.
    // Let's grab the shop of the first item.
    if (cart.length === 0) return;
    const firstItem = cart[0].item;
    const shop = shops.find((s) => s.id === firstItem.shopId) || shops[0];

    const subtotal = cart.reduce((acc, curr) => acc + curr.item.price * curr.quantity, 0);
    const deliveryFee = shop.deliveryFee;
    const actualDiscount = discountAmount || 0;
    const taxableAmount = Math.max(0, subtotal - actualDiscount);
    const vat = Math.round(taxableAmount * 0.14 * 100) / 100;
    const total = Math.round((taxableAmount + deliveryFee + vat) * 100) / 100;

    const newOrder: Order = {
      id: Math.floor(100000 + Math.random() * 900000).toString(),
      date: new Date().toLocaleString('ar-EG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      shopId: shop.id,
      shopName: shop.name,
      shopImage: shop.image,
      items: cart.map((i) => ({
        id: i.item.id,
        name: i.item.name,
        price: i.item.price,
        quantity: i.quantity,
      })),
      subtotal,
      deliveryFee,
      vat,
      discount: actualDiscount,
      total,
      status: 'received',
      address,
      phone,
      paymentMethod,
      notes: notes || undefined,
      trackingProgress: 5,
    };

    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    setActiveOrderId(newOrder.id);
    setCart([]); // Clear Cart
    setActiveTab('tracking'); // Auto jump to live tracking!
    showToast('تم تقديم طلبك بنجاح! جاري التوصيل 🛵', 'success');
  };

  // Track order state updates
  const handleUpdateOrderStatus = (status: OrderStatus, progress: number) => {
    if (!activeOrderId) return;
    setOrders(
      orders.map((o) =>
        o.id === activeOrderId
          ? { ...o, status, trackingProgress: progress }
          : o
      )
    );
  };

  // Re-order past order handler
  const handleReorder = (pastOrder: Order) => {
    // Clear cart and add everything from the past order
    const itemsToAdd: CartItem[] = [];
    let itemsFoundCount = 0;

    pastOrder.items.forEach((pastItem) => {
      const originalMenuItem = menuItems.find((m) => m.id === pastItem.id);
      if (originalMenuItem) {
        itemsToAdd.push({
          item: originalMenuItem,
          quantity: pastItem.quantity,
        });
        itemsFoundCount++;
      }
    });

    if (itemsToAdd.length > 0) {
      setCart(itemsToAdd);
      setActiveTab('cart');
      showToast(`تمت استعادة ${itemsFoundCount} من منتجات طلبك السابق إلى السلة!`);
    } else {
      showToast('عذراً، لم نعد نوفر هذه السلع حالياً', 'error');
    }
  };

  // Filtering Shops based on search and tab
  const filteredShops = shops.filter((shop) => {
    const matchesCategory = shop.category === selectedCategory;
    const matchesSearch =
      shop.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shop.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  // Search through all items across shops (allowing direct product searches)
  const matchingItems = searchQuery.trim()
    ? menuItems.filter((item) =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const currentSelectedShop = shops.find((s) => s.id === selectedShopId);
  const currentShopItems = menuItems.filter((i) => i.shopId === selectedShopId);

  // Delivery fee calculation for active cart
  const currentCartDeliveryFee = cart.length > 0
    ? shops.find((s) => s.id === cart[0].item.shopId)?.deliveryFee || 10
    : 10;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans" dir="rtl">
      
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-5 left-5 z-50 flex items-center gap-2 rounded-2xl bg-slate-900/95 backdrop-blur text-white px-5 py-3 shadow-xl border border-white/10 animate-bounce">
          <div className={`h-2.5 w-2.5 rounded-full ${toast.type === 'success' ? 'bg-emerald-400' : toast.type === 'info' ? 'bg-sky-400' : 'bg-red-400'}`} />
          <span className="text-xs font-bold">{toast.message}</span>
          <button onClick={() => setToast(null)} className="text-white/40 hover:text-white mr-2">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Top Bar with address details */}
      <div className="bg-white border-b border-slate-100 py-2 px-4 text-xs font-bold text-slate-500 text-center flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 justify-center sm:justify-start">
          <MapPin className="h-4 w-4 text-red-500 shrink-0" />
          <span>التوصيل إلى:</span>
          <span className="text-slate-800 bg-slate-50 px-2 py-1 rounded-md">قنا، مركز فرشوط 📍</span>
        </div>
        <div className="flex items-center gap-2 justify-center">
          <span className="inline-block bg-red-50 text-red-500 px-2 py-0.5 rounded-full text-[10px]">
            عرض خاص ✨
          </span>
          <span>استخدم كود <span className="text-red-500">MASR30</span> للحصول على خصم 30% فوراً في فرشوط ومحافظة قنا!</span>
        </div>
      </div>

      {/* Main Navigation Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-16 sm:h-20 flex items-center justify-between gap-4">
          
          {/* App Brand Logo */}
          <div
            onClick={() => {
              setSelectedShopId(null);
              setActiveTab('explore');
            }}
            className="flex items-center gap-2 cursor-pointer group shrink-0"
          >
            <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-2xl bg-gradient-to-tr from-red-600 to-red-500 flex items-center justify-center shadow-lg shadow-red-100 group-hover:scale-105 transition-transform">
              <span className="text-xl sm:text-2xl">🛵</span>
            </div>
            <div>
              <span className="font-black text-lg sm:text-xl text-slate-800 tracking-tight block">طلبات فرشوط</span>
              <span className="text-[10px] text-slate-400 font-bold block -mt-1">مطاعم • بقالة • كافيهات</span>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1.5 md:gap-3">
            <button
              onClick={() => {
                setSelectedShopId(null);
                setActiveTab('explore');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer ${
                activeTab === 'explore'
                  ? 'bg-red-500 text-white shadow-md shadow-red-100'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Compass className="h-4 w-4" />
              <span className="hidden sm:inline">الرئيسية</span>
            </button>

            <button
              onClick={() => setActiveTab('cart')}
              className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer ${
                activeTab === 'cart'
                  ? 'bg-red-500 text-white shadow-md shadow-red-100'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <ShoppingBag className="h-4 w-4" />
              <span className="hidden sm:inline">السلة</span>
              {cart.length > 0 && (
                <span className="absolute -top-1.5 -left-1.5 h-5 w-5 rounded-full bg-red-600 text-white text-[10px] flex items-center justify-center font-bold border-2 border-white animate-pulse">
                  {cart.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-red-500 text-white shadow-md shadow-red-100'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <History className="h-4 w-4" />
              <span className="hidden sm:inline">طلباتي السابقة</span>
              {orders.length > 0 && (
                <span className="bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded text-[10px] font-bold">
                  {orders.length}
                </span>
              )}
            </button>

            {/* Active order live tracking tab */}
            {activeOrderId && activeOrder && (
              <button
                onClick={() => setActiveTab('tracking')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold border border-red-200 transition-all cursor-pointer ${
                  activeTab === 'tracking'
                    ? 'bg-red-500 text-white border-red-500 shadow-md shadow-red-100'
                    : 'bg-red-50/50 text-red-600 hover:bg-red-50'
                }`}
              >
                <span className="relative flex h-2 w-2 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                </span>
                <span className="hidden md:inline">تتبع طلبك النشط</span>
                <span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded font-bold">
                  مباشر
                </span>
              </button>
            )}

            {/* Merchant / Admin Panel Tab */}
            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-extrabold transition-all cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-slate-900 text-white shadow-md shadow-slate-200'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span className="text-sm">⚙️</span>
              <span className="hidden sm:inline">لوحة التحكم</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 py-6 sm:py-8 flex-grow w-full">
        
        {/* TAB 1: EXPLORE / HOME PAGE */}
        {activeTab === 'explore' && (
          <div className="space-y-8">
            
            {/* If no specific shop is selected: Show Category selection & Shop grid */}
            {!selectedShopId ? (
              <>
                {/* Immersive Welcome Banner */}
                <div className="relative overflow-hidden rounded-3xl bg-slate-900 text-white p-6 sm:p-10 shadow-xl border border-slate-800">
                  {/* Decorative background vectors */}
                  <div className="absolute top-0 left-0 w-64 h-64 bg-red-500/10 rounded-full blur-3xl -translate-x-12 -translate-y-12" />
                  <div className="absolute bottom-0 right-0 w-80 h-80 bg-red-600/10 rounded-full blur-3xl translate-x-24 translate-y-24" />

                  <div className="relative max-w-xl space-y-4">
                    <span className="inline-flex items-center gap-1.5 bg-white/10 text-red-400 px-3 py-1 rounded-full text-xs font-bold">
                      <Sparkles className="h-3.5 w-3.5" />
                      <span>توصيل فائق السرعة بمركز فرشوط خلال 20 دقيقة 🚀</span>
                    </span>
                    <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
                      كل ما تحتاجه من وجبات وقهوة يصلك لباب بيتك بفرشوط!
                    </h1>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-medium">
                      اختر من بين أفضل المحلات والمطاعم في فرشوط، واستمتع بتتبع فوري لطلبك خطوة بخطوة مع كباتن التوصيل السريع.
                    </p>
                  </div>
                </div>

                {/* Live Search and Filters */}
                <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-100 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
                  {/* Search Bar */}
                  <div className="relative w-full md:max-w-md">
                    <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 h-5 w-5" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="ابحث عن وجبات، برجر، فواكه، قهوة مختصة أو اسم المتجر..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pr-11 pl-4 text-sm text-slate-800 focus:outline-none focus:border-red-400 focus:bg-white placeholder-slate-400 transition-all font-medium"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                      >
                        إلغاء
                      </button>
                    )}
                  </div>

                  {/* Category Filter Tabs */}
                  <div className="flex bg-slate-100 p-1 rounded-xl w-full md:w-auto shrink-0 justify-between">
                    <button
                      onClick={() => {
                        setSelectedCategory('restaurants');
                        setSearchQuery('');
                      }}
                      className={`flex-grow md:flex-grow-0 flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-extrabold transition-all cursor-pointer ${
                        selectedCategory === 'restaurants'
                          ? 'bg-white text-slate-800 shadow-sm'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      <Utensils className="h-4 w-4 text-red-500" />
                      <span>🍔 المطاعم</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedCategory('grocery');
                        setSearchQuery('');
                      }}
                      className={`flex-grow md:flex-grow-0 flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-extrabold transition-all cursor-pointer ${
                        selectedCategory === 'grocery'
                          ? 'bg-white text-slate-800 shadow-sm'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      <Store className="h-4 w-4 text-red-500" />
                      <span>🥦 البقالة والسوبرماركت</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedCategory('cafes');
                        setSearchQuery('');
                      }}
                      className={`flex-grow md:flex-grow-0 flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-extrabold transition-all cursor-pointer ${
                        selectedCategory === 'cafes'
                          ? 'bg-white text-slate-800 shadow-sm'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      <Coffee className="h-4 w-4 text-red-500" />
                      <span>☕ الكافيهات</span>
                    </button>
                  </div>
                </div>

                {/* If there is a search query and product search results found */}
                {searchQuery.trim() && matchingItems.length > 0 && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 pb-1">
                      <TrendingUp className="h-5 w-5 text-red-500" />
                      <h3 className="font-extrabold text-lg text-slate-800">المنتجات المطابقة للبحث ({matchingItems.length})</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {matchingItems.map((item) => {
                        const cartItem = cart.find((c) => c.item.id === item.id);
                        return (
                          <ItemCard
                            key={item.id}
                            item={item}
                            cartQuantity={cartItem?.quantity || 0}
                            onAdd={() => handleAddToCart(item)}
                            onRemove={() => handleRemoveFromCart(item)}
                          />
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Shops Listings Header */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-xl font-extrabold text-slate-800 flex items-center gap-2">
                        {selectedCategory === 'restaurants' ? '🍔 المطاعم الموصى بها لك' : selectedCategory === 'grocery' ? '🥦 البقالات والسوبرماركت القريب' : '☕ الكافيهات ومحلات التحلية'}
                      </h2>
                      <p className="text-xs text-slate-400 mt-1">توصيل سريع، أسعار ممتازة وجودة مضمونة</p>
                    </div>
                    <span className="text-xs bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg font-bold">
                      {filteredShops.length} متجر متاح
                    </span>
                  </div>

                  {filteredShops.length === 0 ? (
                    <div className="text-center py-12 bg-white rounded-3xl border border-slate-100 shadow-sm">
                      <p className="text-slate-400 font-bold mb-2">عذراً، لم نجد أي متجر يطابق هذا البحث</p>
                      <p className="text-xs text-slate-400">جرب البحث بكلمات أخرى أو تصفح الأقسام الرئيسية</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredShops.map((shop) => (
                        <ShopCard
                          key={shop.id}
                          shop={shop}
                          onClick={() => setSelectedShopId(shop.id)}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </>
            ) : (
              /* IF A SPECIFIC SHOP IS SELECTED: Show Store Menu Page */
              currentSelectedShop && (
                <div className="space-y-6">
                  {/* Back button */}
                  <button
                    onClick={() => {
                      setSelectedShopId(null);
                      setSearchQuery('');
                    }}
                    className="flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-xl text-sm font-bold transition-all cursor-pointer"
                  >
                    <ArrowRight className="h-4.5 w-4.5" />
                    <span>العودة إلى قائمة المتاجر</span>
                  </button>

                  {/* Shop Cover Banner */}
                  <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white h-56 sm:h-64 shadow-lg">
                    <img
                      src={currentSelectedShop.image}
                      alt={currentSelectedShop.name}
                      referrerPolicy="no-referrer"
                      className="absolute inset-0 h-full w-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                    <div className="absolute bottom-0 right-0 left-0 p-6 sm:p-8 space-y-3">
                      {currentSelectedShop.featured && (
                        <span className="bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow">
                          متجر مميز 🔥
                        </span>
                      )}
                      <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">{currentSelectedShop.name}</h1>
                      
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-200 font-bold">
                        <div className="flex items-center gap-1 bg-white/20 px-2 py-1 rounded-lg">
                          <span>⭐️ {currentSelectedShop.rating}</span>
                          <span className="text-[10px] text-slate-300">({currentSelectedShop.reviewsCount}+ تقييم)</span>
                        </div>
                        <div>• توصيل في {currentSelectedShop.deliveryTime} دقيقة</div>
                        <div>• رسوم التوصيل: {currentSelectedShop.deliveryFee === 0 ? 'مجاني' : `${currentSelectedShop.deliveryFee} ج.م`}</div>
                        <div>• الحد الأدنى: {currentSelectedShop.minOrder} ج.م</div>
                        <div>• المسافة: {currentSelectedShop.distance} كم</div>
                      </div>
                    </div>
                  </div>

                  {/* Menu Items Grid Header */}
                  <div className="space-y-4">
                    <h3 className="font-extrabold text-lg text-slate-800 pb-2 border-b border-slate-100 flex items-center gap-2">
                      <Compass className="h-5 w-5 text-red-500" />
                      <span>قائمة المنتجات والمأكولات المتوفرة</span>
                    </h3>

                    {currentShopItems.length === 0 ? (
                      <div className="text-center py-12 bg-white rounded-3xl border border-slate-100 shadow-sm">
                        <p className="text-slate-400 font-bold">عذراً، لا تتوفر منتجات في هذا المتجر حالياً</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {currentShopItems.map((item) => {
                          const cartItem = cart.find((c) => c.item.id === item.id);
                          return (
                            <ItemCard
                              key={item.id}
                              item={item}
                              cartQuantity={cartItem?.quantity || 0}
                              onAdd={() => handleAddToCart(item)}
                              onRemove={() => handleRemoveFromCart(item)}
                            />
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )
            )}
          </div>
        )}

        {/* TAB 2: ACTIVE CART & CHECKOUT PAGE */}
        {activeTab === 'cart' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h2 className="text-xl font-extrabold text-slate-800">حقيبة المشتريات والطلب</h2>
                <p className="text-xs text-slate-400 mt-1">تأكد من المنتجات واملأ تفاصيل التوصيل لإرسال طلبك فوراً</p>
              </div>
              <button
                onClick={() => setActiveTab('explore')}
                className="text-xs text-red-500 font-extrabold flex items-center gap-1 hover:underline cursor-pointer"
              >
                <span>متابعة التسوق والطلب</span>
                <ChevronLeft className="h-4 w-4" />
              </button>
            </div>

            <Cart
              cartItems={cart}
              onUpdateQuantity={handleUpdateCartQty}
              onClearCart={handleClearCart}
              onCheckout={handleCheckout}
              deliveryFee={currentCartDeliveryFee}
            />
          </div>
        )}

        {/* TAB 3: ORDER HISTORY PAGE */}
        {activeTab === 'history' && (
          <OrderHistory
            orders={orders}
            onReorder={handleReorder}
            onTrack={(order) => {
              setActiveOrderId(order.id);
              setActiveTab('tracking');
            }}
          />
        )}

        {/* TAB 4: ACTIVE TRACKER PAGE */}
        {activeTab === 'tracking' && (
          activeOrderId && activeOrder ? (
            <OrderTracker
              order={activeOrder}
              onClose={() => setActiveTab('history')}
              onUpdateStatus={handleUpdateOrderStatus}
            />
          ) : (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-100 shadow-sm max-w-md mx-auto">
              <span className="text-4xl block mb-4">🛵</span>
              <h3 className="font-extrabold text-slate-800 text-base mb-2">لا يوجد أي طلب نشط لتتبعه حالياً</h3>
              <p className="text-xs text-slate-400 mb-6 px-4">عندما تقوم بتقديم طلب جديد، ستظهر خريطة تتبع الكابتن المباشرة هنا لمتابعة طلبك خطوة بخطوة!</p>
              <button
                onClick={() => setActiveTab('explore')}
                className="bg-red-500 text-white rounded-xl px-6 py-2.5 text-sm font-bold shadow hover:bg-red-600 transition-colors cursor-pointer"
              >
                تصفح المطاعم والمتاجر الآن
              </button>
            </div>
          )
        )}

        {/* TAB 5: MERCHANT / ADMIN DASHBOARD */}
        {activeTab === 'admin' && (
          <AdminPanel
            shops={shops}
            menuItems={menuItems}
            onAddShop={handleAddShop}
            onDeleteShop={handleDeleteShop}
            onAddMenuItem={handleAddMenuItem}
            onDeleteMenuItem={handleDeleteMenuItem}
          />
        )}

      </main>

      {/* Footer credits and information */}
      <footer className="bg-white border-t border-slate-100 py-6 text-center text-xs text-slate-400 font-medium">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p>تطبيق طلبات فرشوط - جميع حقوق النشر محفوظة باسم حسن الدربي © 2026</p>
          <p className="text-[10px] text-slate-300">مطاعم بقالة وكافيهات • جمهورية مصر العربية 🇪🇬</p>
        </div>
      </footer>
    </div>
  );
}
